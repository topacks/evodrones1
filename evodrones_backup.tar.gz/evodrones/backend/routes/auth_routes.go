package routes

import (
	"github.com/gofiber/fiber/v2"
	"github.com/root/evodrones/backend/controllers"
)

func SetupAuthRoutes(app *fiber.App, authController *controllers.AuthController) {
	// Rotas públicas de autenticação
	auth := app.Group("/api/auth")
	auth.Post("/register", authController.Register)
	auth.Post("/login", authController.Login)
}
